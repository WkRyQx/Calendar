<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: log-reg.php");
    exit();
}

$userId = $_SESSION['user_id'];

if (isset($_GET['mod'])) {
    $valasztas = $_GET['mod']; // 'dark' vagy 'light'
    setcookie("tema", $valasztas, time() + (86400 * 30), "/"); 
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$stilus = $_COOKIE['tema'] ?? 'light';

// Adatbázis kapcsolat a profilképhez
$db_host = "localhost"; $db_name = "calendar"; $db_user = "root"; $db_pass = "";
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
    $stmtUser = $pdo->prepare("SELECT profilkep, nev FROM felhasznalo WHERE id = ?");
    $stmtUser->execute([$userId]);
    $userData = $stmtUser->fetch(PDO::FETCH_ASSOC);
    $profilkep = $userData['profilkep'] ?? null;
    if (!isset($_SESSION['user_name'])) {
        $_SESSION['user_name'] = $userData['nev'] ?? 'User';
    }
} catch (PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
    <link rel="stylesheet" href="profil.css">
    <link rel="stylesheet" href="home.css">
    <title>Személyes adatok</title>
</head>
<body class="<?= isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark' ? 'dark-mode' : '' ?>">
    <div class="header-controls">
        <div class="left-controls">
            <button type="button" class="back-btn" onclick="history.back()">
                <i class="fa-solid fa-arrow-left"></i>
            </button>
            <div class="header-title">
                <span>Személyes adatok</span>
            </div>
        </div>

        <div class="right-controls">
            <div class="dropdown3" title="Beállítások">
                <i class="fa-solid fa-gear"></i>
                <div class="textBox"></div>
                <div class="option">
                    <form method="get" action="settings.php"><div>Beállítások</div></form>
                    <form method="Post" action="kijelentkezes.php" class="kijelentkezes"><div>Kijelentkezés</div></form>
                </div>
            </div>
            <a href="profil.php" id="profil" title="Profil">
                <div class="profile-icon">
                    <?php if (!empty($profilkep)): ?>
                        <img src="Profilkepek/<?= $profilkep ?>" alt="profil">
                    <?php else: ?>
                        <?= strtoupper($_SESSION["user_name"][0]) ?>
                    <?php endif; ?>
                </div>
            </a>
        </div>
    </div>
    </div>

    <div id="navdiv">
        <nav id="nav">
            <a href="profil.php" class="menupont">
                <div class="menupontDiv">
                    <i class="fa-solid fa-house"></i>
                    <div class="menupontSpan">
                        <span>Kezdőlap</span>
                    </div>     
                </div>
            </a>

            <br>
            <a href="szemelyes_adatok.php" class="menupont">
                <div class="menupontDiv">
                    <i class="fa-solid fa-user"></i>
                    <div class="menupontSpan">
                        <span>Személyes adatok</span>
                    </div>
                </div>
            </a>

            <br>
            <a href="biztonsag.php" class="menupont">
                <div class="menupontDiv">
                    <i class="fa-solid fa-lock"></i>
                    <div class="menupontSpan">
                        <span>Biztonság</span>
                    </div>
                </div>
            </a>

            <br>
        </nav>
    </div>
<script>
    // Dropdownok
    document.querySelectorAll('.dropdown3').forEach((dropdown, index) => {
        // Visszaállítás betöltéskor
        const isOpen = localStorage.getItem(`dropdown_${index}`) === 'true';
        if (isOpen) dropdown.classList.add('active');
        dropdown.addEventListener('click', (e) => {
            // Ha az opciókra vagy a szerkesztés gombra kattintunk, ne csukódjon be
            if (e.target.closest('.option') || e.target.closest('.edit-group')) return;
            
            e.stopPropagation();
            dropdown.classList.toggle('active');
            
            // Állapot mentése
            localStorage.setItem(`dropdown_${index}`, dropdown.classList.contains('active'));
        });
        dropdown.querySelectorAll('.option div').forEach(opt => {
            opt.addEventListener('click', (e) => {
                dropdown.classList.remove('active');
                localStorage.setItem(`dropdown_${index}`, 'false');
                const form = opt.closest('form');
                if (form) form.submit();
            });
        });
    });

    document.addEventListener('click', (e) => {
        document.querySelectorAll('.dropdown3').forEach((d) => {
            const allDropdowns = Array.from(document.querySelectorAll('.dropdown, .dropdown2, .dropdown3, .dropdown4'));
            const globalIndex = allDropdowns.indexOf(d);
            if (!d.contains(e.target) && d.classList.contains('active')) {
                d.classList.remove('active');
                if (globalIndex !== -1) {
                    localStorage.setItem(`dropdown_${globalIndex}`, 'false');
                }
            }
        });
    });
</script>
</body>
</html>