<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: log-reg.php");
    exit();
}

$userId = $_SESSION['user_id'];


$lang = $_SESSION['lang'] ?? 'hun';

$langFile = __DIR__ . "/lang/$lang.php";

if (!file_exists($langFile)) {
    die("Nyelvi fájl nem találtahó!: $langFile");
}

$translations = include $langFile;


if (isset($_GET['mod'])) {
    $valasztas = $_GET['mod']; // 'dark' vagy 'light'
    setcookie("tema", $valasztas, time() + (86400 * 30), "/"); 
    header("Location: " . $_SERVER['PHP_SELF']);
    exit;
}

$stilus = $_COOKIE['tema'] ?? 'light';

// Adatbázis kapcsolat a profilképhez
$db_host = "localhost"; $db_name = "calendar"; $db_user = "root"; $db_pass = "";
try {
    $pdo = new PDO("mysql:host=$db_host;dbname=$db_name;charset=utf8", $db_user, $db_pass);
    $stmtUser = $pdo->prepare("SELECT profilkep, nev FROM felhasznalo WHERE id = ?");
    $stmtUser->execute([$userId]);
    $userData = $stmtUser->fetch(PDO::FETCH_ASSOC);
    $profilkep = $userData['profilkep'] ?? null;
    if (!isset($_SESSION['user_name'])) {
        $_SESSION['user_name'] = $userData['nev'] ?? 'User';
    }
} catch (PDOException $e) {}
?>


<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Beállítások</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.0.1/css/all.min.css">
    <link rel="stylesheet" href="home.css">
    <link rel="stylesheet" href="settings.css">
</head>
<body class="<?= isset($_COOKIE['theme']) && $_COOKIE['theme'] === 'dark' ? 'dark-mode' : '' ?>">
    <div class="header-controls">
        <div class="left-controls">
            <button type="button" class="back-btn" onclick="history.back()">
                <i class="fa-solid fa-arrow-left"></i>
            </button>
            <div class="header-title">
                <span><?= $translations['szoveg1'] ?></span>
            </div>
        </div>

        <div class="center-controls">
            <div class="search-bar">
                <input type="text" id="searchInput" placeholder="<?= $translations['search1'] ?? 'Keresés...' ?>">
                <button onclick="kereses()"><i class="fa-solid fa-magnifying-glass"></i></button>
            </div>
        </div>

        <div class="right-controls">
            <div class="dropdown3" title="Beállítások">
                <i class="fa-solid fa-gear"></i>
                <div class="textBox"></div>
                <div class="option">
                    <form method="get" action="settings.php"><div>Beállítások</div></form>
                    <form method="Post" action="kijelentkezes.php" class="kijelentkezes"><div>Kijelentkezés</div></form>
                </div>
            </div>
            <a href="profil.php" id="profil" title="Profil">
                <div class="profile-icon">
                    <?php if (!empty($profilkep)): ?>
                        <img src="Profilkepek/<?= $profilkep ?>" alt="profil">
                    <?php else: ?>
                        <?= strtoupper($_SESSION["user_name"][0]) ?>
                    <?php endif; ?>
                </div>
            </a>
        </div>
    </div>
    <div class="menu">
        <div class="menu2">
            <h3><?= $translations['szoveg2']?></h3>
            <hr>
            <div class="beltartalom">
                <label><?= $translations['label']?></label>
                <select id="languageSwitcher">
                    <option value="hun" <?= $lang === 'hun' ? 'selected': '' ?>>Magyar - Hungarian</option>
                    <option value="eng" <?= $lang === 'eng' ? 'selected': '' ?>>Angol - English</option>
                    <option value="deu" <?= $lang === 'deu' ? 'selected': '' ?>>Német - Deutsch</option>
                </select>
                <hr>
                <label><?= $translations['label2']?></label>
                <select name="timezone">
                    <option value="Europe/Budapest">Budapest (GMT+1)</option>
                </select>
            </div>
            <hr>
        </div>
        <div class="menu2">
            <h3><?= $translations['szoveg3']?></h3>
            <hr>
            <div class="beltartalom">
                <label><?= $translations['reminding']?></label>
                <select name="reminder">
                    <option value="5"><?= $translations['reminder1']?></option>
                    <option value="10"><?= $translations['reminder2']?></option>
                    <option value="30"><?= $translations['reminder3']?></option>
                </select>
            </div>
            <hr>
        </div>
        <div class="menu2_1">
            <h3><?= $translations['szoveg5']?></h3>
            <hr>
            <div class="beltartalom">
                <label><?= $translations['eventsee1']?></label>
                <select name="reminder">
                    <option value="1"><?= $translations['eventsee2']?></option>
                    <option value="2"><?= $translations['eventsee3']?></option>
                    <option value="3"><?= $translations['eventsee4']?></option>
                </select>
            </div>
            <hr>
        </div>
    </div>

<script>
    function kereses() {
    let szo = document.getElementById("searchInput").value.toLowerCase();
    if (!szo) return;

    clearHighlight();

    document.querySelectorAll("*").forEach(el => {
        if (el.childNodes.length === 1 && el.childNodes[0].nodeType === 3) {
            let text = el.innerText;
            if (text && text.toLowerCase().includes(szo)) {
                el.innerHTML = text.replace(new RegExp(szo, "gi"), '<span class="highlight">$&</span>');
            }
        }
    });

    document.querySelectorAll("option").forEach(option => {
        if (option.text.toLowerCase().includes(szo)) {
            option.selected = true;
            option.parentElement.style.background = "yellow";
        }
    });
    }

    function clearHighlight() {
        document.querySelectorAll(".highlight").forEach(e => {
            e.replaceWith(e.textContent);
        });

        document.querySelectorAll("button,input,option").forEach(e => {
            e.style.background = "";
        });
    }

    document.getElementById('languageSwitcher').addEventListener('change', function () {
        fetch('set-language.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: 'lang=' + this.value
        }).then(() => location.reload());
    });

     // Dropdownok
        document.querySelectorAll(' .dropdown3').forEach((dropdown, index) => {
            // Visszaállítás betöltéskor
            const isOpen = localStorage.getItem(`dropdown_${index}`) === 'true';
            if (isOpen) dropdown.classList.add('active')    
            dropdown.addEventListener('click', (e) => {
                // Ha az opciókra vagy a szerkesztés gombra kattintunk, ne csukódjon be
                if (e.target.closest('.option') || e.target.closest('.edit-group')) return;

                e.stopPropagation();
                dropdown.classList.toggle('active');

                // Állapot mentése
                localStorage.setItem(`dropdown_${index}`, dropdown.classList.contains('active'));
            });
            dropdown.querySelectorAll('.option div').forEach(opt => {
                opt.addEventListener('click', (e) => {
                    const form = opt.closest('form');
                    if (form) form.submit();
                });
            });
        });


    document.addEventListener('click', (e) => {
                document.querySelectorAll('.dropdown3').forEach((d) => {
                    const allDropdowns = Array.from(document.querySelectorAll('.dropdown, .dropdown2, .dropdown3, .dropdown4'));
                    const globalIndex = allDropdowns.indexOf(d);

                    if (!d.contains(e.target) && d.classList.contains('active')) {
                        d.classList.remove('active');
                        if (globalIndex !== -1) {
                            localStorage.setItem(`dropdown_${globalIndex}`, 'false');
                        }
                    }
                });
            });
</script>
</body>
</html>