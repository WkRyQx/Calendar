<?php

return [
    'szoveg1' => 'Beállítások',
    'szoveg2' => 'Általános beállítások',
    'szoveg3' => 'Speciális beállítások',
    'szoveg4' => 'Profil specifikus beállítások',
    'szoveg5' => 'Adatvédelem és Biztonság',
    'place1' => 'Név módosítása:',
    'place2' => 'Jelszó módosítása:',
    'place3' => 'Email módosítása:',
    'reminder1' => '5 perc',
    'reminder2' => '10 perc',
    'reminder3' => '30 perc',
    'reminding' => 'Alapértelmezett emlékeztető:',
    'profile' =>'Profilkép feltöltése',
    'profile2' =>'Adatok mentése',
    'label' => 'Nyelv: ',
    'label2' => 'Időzóna: ',
    'profilelabel' => 'Profil adatok: ',
    'eventsee1' => 'Esemény láthatóság: ',
    'eventsee2' => 'Privát',
    'eventsee3' => 'Csak cím',
    'eventsee4' => 'Nyilvános',
    'login1' => 'Felhasználóhév: ',
    'login2' => 'Jelszó: ',
    'login3' => 'Bejelentkezés',
    'login4' => 'Regisztráció',
    'login5' => 'Email: ',
    'search1' => 'Írj ide a kereséshez:',
    'search2' => 'Keresés',
]

?>