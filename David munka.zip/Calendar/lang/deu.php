<?php

return [
    'szoveg1' => 'Einstellungen',
    'szoveg2' => 'Allgemeine Einstellungen',
    'szoveg3' => 'Spezielle Einstellungen',
    'szoveg4' => 'Profilspezifische Einstellungen',
    'szoveg5' => 'Datenschutz und Sicherheit',
    'place1' => 'Namensänderung:',
    'place2' => 'Passwort ändern:',
    'place3' => 'E-Mail-Adresse ändern:',
    'reminder1' => '5 Minuten',
    'reminder2' => '10 Minuten',
    'reminder3' => '30 Minuten',
    'reminding' => 'Standard-Erinnerung:',
    'profile' =>'Profilbild hochladen',
    'profile2' =>'Daten speichern',
    'label' => 'Sprache',
    'label2' => 'Zeitzone: ',
    'profilelabel' => 'Profilangaben: ',
    'eventsee1' => 'Sichtbarkeit der Verabstaltung: ',
    'eventsee2' => 'Privat',
    'eventsee3' => 'Nur Titel',
    'eventsee4' => 'Öffentlich',
    'login1' => 'Namensänderung: ',
    'login2' => 'Passwort ändern: ',
    'login3' => 'Anmelden',
    'login4' => 'Registrierung',
    'login5' => 'E-Mail-Adresse: ',
    'search1' => 'Geben Sie hier Ihren Suchbegriff ein:',
    'search2' => 'Suche',
]

?>