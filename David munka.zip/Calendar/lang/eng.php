<?php

return [
    'szoveg1' => 'Settings',
    'szoveg2' => 'General settings',
    'szoveg3' => 'Special settings',
    'szoveg4' => 'Profile-specific settings',
    'szoveg5' => 'Privacy and Security',
    'place1' => 'Change name:',
    'place2' => 'Change password:',
    'place3' => 'Change email:',
    'reminder1' => '5 minutes',
    'reminder2' => '10 minutes',
    'reminder3' => '30 minutes',
    'reminding' => 'Default reminder:',
    'profile' =>'Upload profile picture',
    'profile2' =>'Saving data',
    'label' => 'Language: ',
    'label2' => 'Time zone: ',
    'profilelabel' => 'Profile data: ',
    'eventsee1' => 'Event visibility: ',
    'eventsee2' => 'Private',
    'eventsee3' => 'Title only',
    'eventsee4' => 'Public',
    'login1' => 'Name: ',
    'login2' => 'Password: ',
    'login3' => 'Login',
    'login4' => 'Sign up',
    'login5' => 'Email address:',
    'search1' => 'Type here to search:',
    'search2' => 'Search',
]

?>