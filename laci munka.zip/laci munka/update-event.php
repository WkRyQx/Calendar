<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'error' => 'Nincs bejelentkezve']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$id = $data['id'] ?? null;
$start = $data['start'] ?? null;
$end = $data['end'] ?? null;

if (!$id || !$start || !$end) {
    echo json_encode(['success' => false, 'error' => 'Hiányzó adatok']);
    exit();
}

$userId = $_SESSION['user_id'];

try {
    $pdo = new PDO("mysql:host=localhost;dbname=calendar;charset=utf8", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $stmt = $pdo->prepare("UPDATE esemeny SET kezdet = ?, vege = ? WHERE id = ? AND felhasznalo_id = ?");
    
    // A dátumot a mai nap dátumával kombináljuk, hogy teljes datetime legyen
    $today = date('Y-m-d');
    $stmt->execute([
        "$today $start:00",
        "$today $end:00",
        $id,
        $userId
    ]);

    echo json_encode(['success' => true]);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}