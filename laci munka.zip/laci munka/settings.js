document.getElementById('languageSwitcher').addEventListener('change', function () {
    fetch('set-language.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: 'lang=' + this.value
    }).then(() => location.reload());
});