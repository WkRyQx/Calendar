// draganddrop.js

let draggedEvent = null;

function dragstartHandler(e) {
    draggedEvent = e.target;

    // Ha még nincs elmentve az eredeti állapot, akkor mentjük
    if (!draggedEvent.dataset.originalSaved) {
        const lines = draggedEvent.innerHTML.split('<br>');
        const timeText = lines[1]; // pl.: "08:30 - 09:30"
        const [startTime, endTime] = timeText.split(' - ');

        draggedEvent.dataset.originalTop = draggedEvent.style.top;
        draggedEvent.dataset.originalHeight = draggedEvent.style.height;
        draggedEvent.dataset.originalStart = startTime.trim();
        draggedEvent.dataset.originalEnd = endTime.trim();
        draggedEvent.dataset.originalHTML = draggedEvent.innerHTML;
        draggedEvent.dataset.originalSaved = 'true'; // jelzés, hogy már mentettük az alaphelyzetet
    }

    e.dataTransfer.effectAllowed = "move";
}

function dropHandler(e) {
    e.preventDefault();
    if (!draggedEvent) return;

    const grid = document.querySelector('.calendar-grid');
    const rect = grid.getBoundingClientRect();
    const y = e.clientY - rect.top + grid.scrollTop;

    // megtartjuk az esemény magasságát
    const height = draggedEvent.offsetHeight;

    // új top érték beállítása
    draggedEvent.style.top = y + "px";

    // új kezdő és végidő számítása
    const startMinutes = Math.round(y);
    const endMinutes = startMinutes + height;

    const startHours = Math.floor(startMinutes / 60);
    const startMins = startMinutes % 60;
    const endHours = Math.floor(endMinutes / 60);
    const endMins = endMinutes % 60;

    const newStart = `${startHours.toString().padStart(2,'0')}:${startMins.toString().padStart(2,'0')}`;
    const newEnd = `${endHours.toString().padStart(2,'0')}:${endMins.toString().padStart(2,'0')}`;

    // frissítjük a szöveget
    const lines = draggedEvent.innerHTML.split('<br>');
    lines[1] = `${newStart} - ${newEnd}`;
    draggedEvent.innerHTML = lines[0] + '<br>' + lines[1] + `<button class="undo-btn">Vissza</button>`;

    // vissza gomb – mindig az eredeti alaphelyzetre állít
    const undoBtn = draggedEvent.querySelector('.undo-btn');
    undoBtn.addEventListener('click', (evt) => {
        evt.stopPropagation();
        draggedEvent.style.top = draggedEvent.dataset.originalTop;
        draggedEvent.style.height = draggedEvent.dataset.originalHeight;
        draggedEvent.innerHTML = draggedEvent.dataset.originalHTML;
    });

    // itt lehet AJAX hívás a szerver frissítésére, pl. update_event.php
    // fetch('update_event.php', { method:'POST', body: JSON.stringify({id: eventId, newStart, newEnd}) })
}

function dragoverHandler(e) {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
}