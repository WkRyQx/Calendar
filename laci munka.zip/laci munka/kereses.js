function kereses() {
    let szo = document.getElementById("searchInput").value.toLowerCase();
    if (!szo) return;

    clearHighlight();

    document.querySelectorAll("*").forEach(el => {
        if (el.childNodes.length === 1 && el.childNodes[0].nodeType === 3) {
            let text = el.innerText;
            if (text && text.toLowerCase().includes(szo)) {
                el.innerHTML = text.replace(new RegExp(szo, "gi"), '<span class="highlight">$&</span>');
            }
        }
    });

    document.querySelectorAll("option").forEach(option => {
        if (option.text.toLowerCase().includes(szo)) {
            option.selected = true;
            option.parentElement.style.background = "yellow";
        }
    });
}

function clearHighlight() {
    document.querySelectorAll(".highlight").forEach(e => {
        e.replaceWith(e.textContent);
    });

    document.querySelectorAll("button,input,option").forEach(e => {
        e.style.background = "";
    });
}