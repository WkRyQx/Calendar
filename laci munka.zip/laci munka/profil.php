<?php

session_start();

$servername = "localhost";
$username = "root";
$password = "";        
$dbname = "calendar";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Hiba a kapcsolódáskor: " . $conn->connect_error);
}

$success = "";
$error = "";

$lang = $_SESSION['lang'] ?? 'hun';

$langFile = __DIR__ . "/lang/$lang.php";

if (!file_exists($langFile)) {
    die("Nyelvi fájl nem találtahó!: $langFile");
}

$translations = include $langFile;

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="profil.css">
    <script src="kereses.js" defer></script>
    <title>Profil</title>
</head>
<body>
    <div id="cimsor">
        <div id="cim">
            <form method="get" action="home.php">
                <button><-</button>
            </form> 
            Fiók
        </div>
    </div>

    <input type="text" id="searchInput" placeholder="<?= $translations['search1']?>">
    <button onclick="kereses()"><?= $translations['search2']?></button>

    <div id="navdiv">
        <nav id="nav">
            <a href="profil.php" class="menupont">

                <div class="menupontDiv">
                    <img src="icons/home.png" alt="anyad" class="icon">
                    <div class="menupontSpan">
                        <span>Kezdőlap</span>
                    </div>     
                </div>
            </a>

            <br>
            <a href="szemelyes_adatok.php" class="menupont">

                <div class="menupontDiv">
                    <img src="icons/user.png" alt="anyad" class="icon">
                    <div class="menupontSpan">
                        <span>Személyes adatok</span>
                    </div>
                </div>
            </a>

            <br>
            <a href="biztonsag.php" class="menupont">

                <div class="menupontDiv">
                    <img src="icons/lock.png" alt="anyad" class="icon">
                    <div class="menupontSpan">
                        <span>Biztonság</span>
                    </div>
                </div>
            </a>

            <br>
        </nav>
    </div>
    
</body>
</html>