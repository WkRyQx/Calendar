<?php

session_start();

$lang = $_SESSION['lang'] ?? 'hun';

$langFile = __DIR__ . "/lang/$lang.php";

if (!file_exists($langFile)) {
    die("Nyelvi fájl nem találtahó!: $langFile");
}

$translations = include $langFile;

?>

<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calendar</title>
    <link rel="stylesheet" href="regist.css">
    <script src="regist.js" defer></script>
</head>
<body>
    <header></header>
    <div class="registration">
        <div>
            <div id="input">
                <input class="input_text" type="text" placeholder="<?= $translations['login1'] ?>">
                <input class="input_text" type="password" placeholder="<?= $translations['login2'] ?>">
            </div>
            <button class="submit_gomb" type="button"><?= $translations['login3'] ?></button>
        </div>
        <div class="gombok_login">
            <button type="button" id="bejGomb2"><a href="login.php"><?= $translations['login3'] ?></a></button>
            <button type="button" id="regGomb2"><a href="registration.php"><?= $translations['login4'] ?></a></button>
        </div>
    </div>
</body>
</html>