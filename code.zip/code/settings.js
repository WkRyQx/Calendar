document.getElementById('languageSwitcher').addEventListener('change', function() {
    fetch('set-language.php', {
        method: 'POST',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: 'lang=' + this.value
    }).then(() => location.reload());
});

function keres() {
    let szoveg = document.getElementById("kereso").value;

    fetch("settings.php?q=", encodeURIComponent(szoveg))
        .then(response => response.text())
        .then(data => {
            document.getElementById("eredmeny").innerHTML = data;

            let talalat = document.getElementById("talalat");
            if(talalat) {
                talalat.scrollIntoView({ behavior: "smooth"});
            }
        });
}